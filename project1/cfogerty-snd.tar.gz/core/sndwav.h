#ifndef WAV_H
#define WAV_H

#include "types.h"

int read_header_wav(snd_t* snd);
int read_info_wav(snd_t* snd);
void write_wav(FILE* out, snd_t* snd);
#endif
