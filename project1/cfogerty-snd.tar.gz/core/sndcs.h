#ifndef CS229_H
#define CS229_H

#include "types.h"

void read_header_cs229(snd_t* snd);
void read_info_cs229(snd_t* snd);
void write_cs229(FILE* out, snd_t* snd);
#endif
