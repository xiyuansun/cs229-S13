#ifndef __CONSTS__
#define __CONSTS__

// Values defined as whitespace.
// Used in some utility and scanner functions.
#define WHITESPACE " \t\r\n\f"

#endif
